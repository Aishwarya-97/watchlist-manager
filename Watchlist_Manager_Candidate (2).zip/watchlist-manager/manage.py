"""Small cross-platform launcher for the interview project (Python 3.11+)."""

from __future__ import annotations

import argparse
from contextlib import closing
import hashlib
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
from datetime import datetime, timezone
import venv

ROOT = Path(__file__).resolve().parent
BACKEND = ROOT / "backend"
VENV = ROOT / ".venv"
PYTHON = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
REQUIREMENTS = BACKEND / "requirements.txt"


def environment() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(BACKEND)
    env.setdefault("WATCHLIST_DB", str(BACKEND / "data" / "watchlist.db"))
    env["PYTHONUNBUFFERED"] = "1"
    return env


def bootstrap() -> None:
    if sys.version_info < (3, 11):
        raise RuntimeError("Python 3.11 or newer is required; Python 3.12 is recommended.")
    if not PYTHON.exists():
        print("Creating a project-local Python environment...", flush=True)
        venv.EnvBuilder(with_pip=True).create(VENV)
    stamp = VENV / "watchlist-requirements.sha256"
    digest = hashlib.sha256(REQUIREMENTS.read_bytes()).hexdigest()
    if not stamp.exists() or stamp.read_text().strip() != digest:
        print("Installing the pinned Python dependencies (internet needed on first setup)...", flush=True)
        subprocess.run(
            [str(PYTHON), "-m", "pip", "install", "--disable-pip-version-check", "-r", str(REQUIREMENTS)],
            check=True,
            cwd=ROOT,
        )
        stamp.write_text(digest + "\n")


def reset_demo(confirmed: bool) -> None:
    if not confirmed:
        raise RuntimeError("Stop the app, then run: python manage.py reset --yes. This resets only this project's default demo database.")
    db = BACKEND / "data" / "watchlist.db"
    if not db.exists():
        print("No default demo database exists. Sample data will be created at the next startup.")
        return
    backup = db.with_name("watchlist-backup-" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ") + ".db")
    with closing(sqlite3.connect(db)) as source, closing(sqlite3.connect(backup)) as target:
        source.backup(target)
    for path in (db, Path(str(db) + "-wal"), Path(str(db) + "-shm")):
        path.unlink(missing_ok=True)
    print(f"Demo database reset. Backup: {backup.name}")
    print("Sample data will be created on the next startup. A custom WATCHLIST_DB path was not changed.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("setup", help="Create the local environment and install Python dependencies")
    start = sub.add_parser("start", help="Run the API and bundled React application")
    start.add_argument("--port", type=int, default=8000)
    start.add_argument("--reload", action="store_true", help="Reload when backend source changes")
    sub.add_parser("test", help="Run the supplied backend smoke and behavior tests")
    reset = sub.add_parser("reset", help="Back up and reset the default local demo database; stop the app first")
    reset.add_argument("--yes", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "reset":
            reset_demo(args.yes)
            return 0
        bootstrap()
        if args.command == "setup":
            print("Setup complete. Run: python manage.py start")
            return 0
        if args.command == "test":
            return subprocess.call(
                [str(PYTHON), "-m", "unittest", "discover", "-s", str(BACKEND / "tests"), "-v"],
                cwd=ROOT,
                env=environment(),
            )
        if not (BACKEND / "static" / "index.html").exists():
            raise RuntimeError("The bundled frontend is missing. Run npm ci and npm run build inside frontend/ first.")
        print(f"Open http://127.0.0.1:{args.port} in your browser. Press Ctrl+C to stop.", flush=True)
        command = [str(PYTHON), "-m", "uvicorn", "app.main:app", "--app-dir", str(BACKEND), "--host", "127.0.0.1", "--port", str(args.port)]
        if args.reload:
            command.extend(["--reload", "--reload-dir", str(BACKEND / "app")])
        return subprocess.call(command, cwd=ROOT, env=environment())
    except (RuntimeError, OSError, subprocess.CalledProcessError) as exc:
        print(f"\nSetup/run failed: {exc}", file=sys.stderr)
        print("See README.md for manual setup and troubleshooting.", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nStopped.")
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
