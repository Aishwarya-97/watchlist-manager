import React, { useCallback, useEffect, useState } from 'react';
import { apiRequest, displayError } from './api.js';
import { useApiResource } from './hooks.js';
import Sidebar from './components/Sidebar.jsx';
import WatchlistView from './components/WatchlistView.jsx';
import CatalogueView from './components/CatalogueView.jsx';
import Modal from './components/Modal.jsx';
import Icon from './components/Icon.jsx';
import { EMPTY_ARRAY, EmptyState, ErrorState, TableSkeleton } from './components/ui.jsx';

function ListForm({ initial, busy, error, onSubmit, onCancel }) {
  const [name, setName] = useState(initial?.name || '');
  const [description, setDescription] = useState(initial?.description || '');
  const [validation, setValidation] = useState('');
  return <form onSubmit={(event) => {
    event.preventDefault();
    if (!name.trim()) {
      setValidation('Enter a name for your watchlist.');
      return;
    }
    setValidation('');
    onSubmit({ name: name.trim(), description: description.trim() });
  }}>
    <div className="form-field">
      <label htmlFor="list-name">Watchlist name <span aria-hidden="true">*</span></label>
      <input id="list-name" data-autofocus value={name} onChange={(event) => setName(event.target.value)}
        placeholder="e.g. Long-term ideas" maxLength={60} required disabled={busy} />
      <span className="field-hint">{name.length}/60 characters</span>
    </div>
    <div className="form-field">
      <label htmlFor="list-description">Description <span className="optional-label">Optional</span></label>
      <textarea id="list-description" value={description} onChange={(event) => setDescription(event.target.value)}
        placeholder="What are you keeping an eye on?" maxLength={160} rows={3} disabled={busy} />
      <span className="field-hint">{description.length}/160 characters</span>
    </div>
    {(validation || error) && <p className="form-error" role="alert"><Icon name="alert" size={16} />{validation || error}</p>}
    <div className="modal-actions">
      <button type="button" className="button button-secondary" disabled={busy} onClick={onCancel}>Cancel</button>
      <button type="submit" className="button button-primary" disabled={busy}>
        {busy && <span className="spinner" />}{initial ? 'Save changes' : 'Create watchlist'}
      </button>
    </div>
  </form>;
}

export default function App() {
  const [view, setView] = useState('watchlists');
  const [selectedListId, setSelectedListId] = useState(null);
  const [listsRevision, setListsRevision] = useState(0);
  const [modal, setModal] = useState(null);
  const [modalBusy, setModalBusy] = useState(false);
  const [modalError, setModalError] = useState('');
  const [notice, setNotice] = useState(null);
  const listResource = useApiResource('/lists', listsRevision);
  const profileResource = useApiResource('/profile');
  const catalogueOverview = useApiResource('/catalog?page=1&page_size=1');
  const lists = listResource.data?.items || EMPTY_ARRAY;
  const selectedList = lists.find((list) => list.id === selectedListId);
  const totalEntries = lists.reduce((sum, list) => sum + list.item_count, 0);

  useEffect(() => {
    if (listResource.data) {
      setSelectedListId((current) => lists.some((list) => list.id === current) ? current : lists[0]?.id || null);
    }
  }, [listResource.data, lists]);

  useEffect(() => {
    if (!notice) return undefined;
    const timeout = setTimeout(() => setNotice(null), notice.type === 'error' ? 8000 : 4500);
    return () => clearTimeout(timeout);
  }, [notice]);

  const refreshLists = useCallback(() => setListsRevision((value) => value + 1), []);
  const notify = useCallback((message, type = 'success') => setNotice({ message, type }), []);

  function openModal(type, list = null) {
    setModalError('');
    setModal({ type, list });
  }

  async function saveList(values) {
    const editing = modal.type === 'rename';
    setModalBusy(true);
    setModalError('');
    try {
      const saved = await apiRequest(editing ? '/lists/' + modal.list.id : '/lists', {
        method: editing ? 'PATCH' : 'POST', body: values,
      });
      setSelectedListId(saved.id);
      refreshLists();
      setModal(null);
      notify(editing ? 'Watchlist updated.' : saved.name + ' is ready for your ideas.');
    } catch (error) {
      setModalError(displayError(error));
    } finally {
      setModalBusy(false);
    }
  }

  async function deleteList() {
    const target = modal.list;
    setModalBusy(true);
    setModalError('');
    try {
      await apiRequest('/lists/' + target.id, { method: 'DELETE' });
      setSelectedListId(null);
      refreshLists();
      setModal(null);
      notify(target.name + ' deleted.');
    } catch (error) {
      setModalError(displayError(error));
    } finally {
      setModalBusy(false);
    }
  }

  return <div className="app-shell">
    <a href="#main-content" className="skip-link">Skip to content</a>
    <Sidebar lists={lists} selectedListId={selectedListId} view={view}
      onChangeView={setView} onSelectList={(id) => { setSelectedListId(id); setView('watchlists'); }}
      onCreate={() => openModal('create')} profile={profileResource.data} />

    <main id="main-content" className="main-content">
      <div className="topline"><span>WORKSPACE <span className="breadcrumb-separator">/</span> {view === 'watchlists' ? 'WATCHLISTS' : 'CATALOGUE'}</span>
        <span className="sample-badge"><span className="status-dot" />Sample workspace</span></div>
      <header className="page-header">
        <div><h1>{view === 'watchlists' ? 'My watchlists' : 'Explore the catalogue'}</h1>
          <p>{view === 'watchlists'
            ? 'A little structure for your next big idea.'
            : 'Discover a symbol. Give it a place in your research.'}</p></div>
        <button type="button" className="button button-primary" onClick={() => openModal('create')}>
          <Icon name="plus" size={17} />New watchlist
        </button>
      </header>

      <section className="overview-grid" aria-label="Workspace overview">
        <div className="overview-card"><div className="overview-label"><span>Your watchlists</span><Icon name="folder" size={17} /></div>
          <div className="overview-value">{listResource.data ? lists.length : '—'}</div><p>Collections with a purpose</p></div>
        <div className="overview-card"><div className="overview-label"><span>Saved entries</span><Icon name="bookmark" size={17} /></div>
          <div className="overview-value">{listResource.data ? totalEntries : '—'}</div><p>Across all your watchlists</p></div>
        <div className="overview-card overview-card-accent"><div className="overview-label"><span>Catalogue symbols</span><Icon name="globe" size={17} /></div>
          <div className="overview-value">{catalogueOverview.data?.total ?? '—'}<span>to explore</span></div>
          <p>Fictional companies. Fresh possibilities.</p></div>
      </section>

      {listResource.error ? <section className="content-panel"><ErrorState message={listResource.error} onRetry={refreshLists} /></section>
        : !listResource.data ? <section className="content-panel"><TableSkeleton /></section>
        : view === 'catalogue' ? <CatalogueView lists={lists} selectedListId={selectedListId}
            onSelectTarget={setSelectedListId} sectors={catalogueOverview.data?.sectors || EMPTY_ARRAY}
            onCreate={() => openModal('create')} onDataChanged={refreshLists} notify={notify} />
        : selectedList ? <WatchlistView key={selectedList.id} list={selectedList}
            onExplore={() => setView('catalogue')} onRename={() => openModal('rename', selectedList)}
            onDelete={() => openModal('delete', selectedList)} onDataChanged={refreshLists} notify={notify} />
        : listResource.loading || lists.length > 0 ? <section className="content-panel"><TableSkeleton /></section>
        : <section className="content-panel"><EmptyState icon="folder" title="Your first watchlist starts here"
            description="Create a collection, give it a name, and make it your own."
            action={<button type="button" className="button button-primary" onClick={() => openModal('create')}><Icon name="plus" size={17} />Create a watchlist</button>} /></section>}

      <footer className="page-footer"><span className="footer-mark"><span className="status-dot" />Sample data · No live market feed</span>
        <span>All prices are fictional reference values in USD.</span></footer>
    </main>

    {notice && <div className={'toast toast-' + notice.type} role={notice.type === 'error' ? 'alert' : 'status'}>
      <span className="toast-icon"><Icon name={notice.type === 'error' ? 'alert' : 'check'} size={18} /></span>
      <span>{notice.message}</span>
      <button type="button" className="icon-button" aria-label="Dismiss notification" onClick={() => setNotice(null)}><Icon name="close" size={16} /></button>
    </div>}

    {modal && modal.type !== 'delete' && <Modal
      title={modal.type === 'rename' ? 'Make it your own' : 'A new place for your ideas'}
      description={modal.type === 'rename' ? 'Update the name and description of this watchlist.' : 'Give your watchlist a name. You can add symbols next.'}
      onClose={() => setModal(null)} busy={modalBusy}>
      <ListForm initial={modal.type === 'rename' ? modal.list : null} busy={modalBusy} error={modalError}
        onSubmit={saveList} onCancel={() => setModal(null)} />
    </Modal>}

    {modal?.type === 'delete' && <Modal title="Delete this watchlist?"
      description={'“' + modal.list.name + '” and its saved entries will be removed. The catalogue will stay available.'}
      onClose={() => setModal(null)} busy={modalBusy} destructive>
      {modalError && <p className="form-error" role="alert">{modalError}</p>}
      <div className="modal-actions">
        <button type="button" data-autofocus className="button button-secondary" onClick={() => setModal(null)} disabled={modalBusy}>Keep watchlist</button>
        <button type="button" className="button button-danger" onClick={deleteList} disabled={modalBusy}>
          {modalBusy && <span className="spinner" />}Delete watchlist
        </button>
      </div>
    </Modal>}
  </div>;
}
