import test from 'node:test';
import assert from 'node:assert/strict';
import { apiRequest, queryString } from './api.js';

test('serializes request bodies and accepts an empty delete response', async (t) => {
  const calls = [];
  t.mock.method(globalThis, 'fetch', async (...args) => {
    calls.push(args);
    return new Response(null, { status: 204 });
  });
  assert.equal(await apiRequest('/lists/4', { method: 'DELETE' }), null);
  await apiRequest('/lists', { method: 'POST', body: { name: 'Research' } });
  assert.equal(calls[0][0], '/api/lists/4');
  assert.equal(calls[1][1].body, '{"name":"Research"}');
  assert.equal(calls[1][1].headers['Content-Type'], 'application/json');
});

test('rejects HTTP errors rather than treating them as success', async (t) => {
  t.mock.method(globalThis, 'fetch', async () => new Response(
    JSON.stringify({ detail: 'Watchlist not found' }),
    { status: 404, headers: { 'Content-Type': 'application/json' } },
  ));
  await assert.rejects(
    apiRequest('/lists/999'),
    (error) => error.status === 404 && error.message === 'Watchlist not found',
  );
});

test('makes API validation errors readable', async (t) => {
  t.mock.method(globalThis, 'fetch', async () => new Response(
    JSON.stringify({ detail: [{ loc: ['body', 'name'], msg: 'Field required' }] }),
    { status: 422, headers: { 'Content-Type': 'application/json' } },
  ));
  await assert.rejects(apiRequest('/lists'), /name: Field required/);
});

test('preserves abort signals and query characters', async (t) => {
  const controller = new AbortController();
  t.mock.method(globalThis, 'fetch', async (url, options) => {
    assert.equal(options.signal, controller.signal);
    throw new DOMException('Aborted', 'AbortError');
  });
  await assert.rejects(apiRequest('/catalog', { signal: controller.signal }), {
    name: 'AbortError',
  });
  assert.equal(queryString({ q: 'A&B', sector: '', page: 1 }), 'q=A%26B&page=1');
});
