import { useEffect, useState } from 'react';
import { apiRequest, displayError } from './api.js';

export function useApiResource(path, revision = 0) {
  const key = path + '|' + revision;
  const [state, setState] = useState({
    key: null,
    path: null,
    data: null,
    loading: Boolean(path),
    error: '',
  });

  useEffect(() => {
    if (!path) return undefined;
    const controller = new AbortController();
    let active = true;

    setState((previous) => ({
      key,
      path,
      data: previous.path === path ? previous.data : null,
      loading: true,
      error: '',
    }));

    apiRequest(path, { signal: controller.signal })
      .then((data) => {
        if (active) setState({ key, path, data, loading: false, error: '' });
      })
      .catch((error) => {
        if (active && error.name !== 'AbortError') {
          setState({ key, path, data: null, loading: false, error: displayError(error) });
        }
      });

    return () => {
      active = false;
      controller.abort();
    };
  }, [path, key]);

  if (!path) return { data: null, loading: false, error: '' };
  return {
    data: state.path === path ? state.data : null,
    loading: state.key !== key || state.loading,
    error: state.key === key ? state.error : '',
  };
}

export function useDebouncedValue(value, delay = 250) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timeout = setTimeout(() => setDebounced(value), delay);
    return () => clearTimeout(timeout);
  }, [value, delay]);
  return debounced;
}
