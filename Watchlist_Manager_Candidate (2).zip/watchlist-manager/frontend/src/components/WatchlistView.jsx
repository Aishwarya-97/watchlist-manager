import React, { useEffect, useState } from 'react';
import { apiRequest, displayError, queryString } from '../api.js';
import { useApiResource, useDebouncedValue } from '../hooks.js';
import Icon from './Icon.jsx';
import { Change, EmptyState, ErrorState, PAGE_SIZE, Pagination, Price, SearchInput, SymbolCell, TableSkeleton } from './ui.jsx';

export default function WatchlistView({ list, onExplore, onRename, onDelete, onDataChanged, notify }) {
  const [query, setQuery] = useState('');
  const search = useDebouncedValue(query.trim());
  const [page, setPage] = useState(1);
  const [revision, setRevision] = useState(0);
  const [removing, setRemoving] = useState(new Set());
  const path = '/lists/' + list.id + '/items?' + queryString({ q: search, page, page_size: PAGE_SIZE });
  const { data, loading, error } = useApiResource(path, revision);

  useEffect(() => {
    if (data && !loading) {
      const lastPage = Math.max(1, Math.ceil(data.total / PAGE_SIZE));
      if (page > lastPage) setPage(lastPage);
    }
  }, [data, loading, page]);

  async function removeItem(item) {
    setRemoving((previous) => new Set(previous).add(item.entry_id));
    try {
      await apiRequest('/lists/' + list.id + '/items/' + item.entry_id, { method: 'DELETE' });
      setRevision((value) => value + 1);
      onDataChanged();
      notify(item.symbol + ' removed from ' + list.name + '.');
    } catch (requestError) {
      notify(displayError(requestError), 'error');
    } finally {
      setRemoving((previous) => {
        const next = new Set(previous);
        next.delete(item.entry_id);
        return next;
      });
    }
  }

  return <section className="content-panel" aria-labelledby="watchlist-heading">
    <div className="panel-heading">
      <div className="panel-title-group">
        <span className="collection-icon"><Icon name="list" size={23} /></span>
        <div><div className="title-with-count"><h2 id="watchlist-heading">{list.name}</h2>
          <span className="count-badge">{list.item_count}</span></div>
          <p>{list.description || 'A collection of ideas worth keeping an eye on.'}</p>
        </div>
      </div>
      <div className="panel-actions">
        <button type="button" className="button button-ghost button-small" onClick={onRename}>
          <Icon name="edit" size={15} />Rename
        </button>
        <button type="button" className="icon-button delete-list-button"
          aria-label={'Delete watchlist ' + list.name} title="Delete watchlist" onClick={onDelete}>
          <Icon name="trash" size={17} />
        </button>
      </div>
    </div>

    <div className="table-toolbar">
      <SearchInput value={query} onChange={(value) => { setQuery(value); setPage(1); }}
        placeholder="Search this watchlist…" label="Search this watchlist" />
      <button type="button" className="button button-secondary button-small" onClick={onExplore}>
        <Icon name="plus" size={16} />Add symbols
      </button>
    </div>

    {error ? <ErrorState message={error} onRetry={() => setRevision((value) => value + 1)} />
      : !data && loading ? <TableSkeleton />
      : data?.items.length === 0 ? <EmptyState
          icon={search ? 'search' : 'bookmark'}
          title={search ? 'No matching symbols' : 'Start with an idea'}
          description={search ? 'Try another symbol or company name.' : 'Explore the catalogue and add your first symbol to this watchlist.'}
          action={search
            ? <button className="button button-secondary" onClick={() => { setQuery(''); setPage(1); }}>Clear search</button>
            : <button className="button button-primary" onClick={onExplore}>Explore catalogue<Icon name="arrow" size={16} /></button>}
        />
      : <div className={'table-wrap' + (loading ? ' refreshing' : '')} aria-busy={loading}>
          <table className="items-table">
            <thead><tr><th scope="col">Company</th><th scope="col">Sector</th><th scope="col" className="exchange-column">Exchange</th>
              <th scope="col" className="number-column">Reference price</th><th scope="col" className="number-column">Change</th>
              <th scope="col" className="action-column"><span className="sr-only">Actions</span></th></tr></thead>
            <tbody>{data?.items.map((item) => <tr key={item.entry_id}>
              <td><SymbolCell item={item} /></td><td><span className="sector-label">{item.sector}</span></td>
              <td className="exchange-column"><span className="exchange-label">{item.exchange}</span></td>
              <td className="number-column"><Price value={item.price} /></td>
              <td className="number-column"><Change value={item.change_percent} /></td>
              <td className="action-column"><button type="button" className="icon-button remove-button"
                onClick={() => removeItem(item)} disabled={loading || removing.has(item.entry_id)}
                aria-label={'Remove ' + item.symbol + ' from ' + list.name} title={'Remove ' + item.symbol}>
                  {removing.has(item.entry_id) ? <span className="spinner" /> : <Icon name="close" size={17} />}
              </button></td>
            </tr>)}</tbody>
          </table>
        </div>}
    {!error && data && data.total > 0 && <Pagination page={page} total={data.total} onChange={setPage} loading={loading} />}
  </section>;
}
