import React, { useEffect, useState } from 'react';
import { apiRequest, displayError, queryString } from '../api.js';
import { useApiResource, useDebouncedValue } from '../hooks.js';
import Icon from './Icon.jsx';
import { Change, EmptyState, ErrorState, PAGE_SIZE, Pagination, Price, SearchInput, SymbolCell, TableSkeleton } from './ui.jsx';

export default function CatalogueView({ lists, selectedListId, onSelectTarget, sectors, onCreate, onDataChanged, notify }) {
  const [query, setQuery] = useState('');
  const search = useDebouncedValue(query.trim());
  const [sector, setSector] = useState('');
  const [page, setPage] = useState(1);
  const [revision, setRevision] = useState(0);
  const [membershipsRevision, setMembershipsRevision] = useState(0);
  const [pending, setPending] = useState(new Set());
  const [recentlySaved, setRecentlySaved] = useState(new Set());
  const selectedList = lists.find((list) => list.id === selectedListId);
  const { data, loading, error } = useApiResource(
    '/catalog?' + queryString({ q: search, sector, page, page_size: PAGE_SIZE }), revision,
  );
  const memberships = useApiResource(
    selectedListId ? '/lists/' + selectedListId + '/items?page=1&page_size=100' : null,
    membershipsRevision,
  );
  const savedItemIds = new Set((memberships.data?.items || []).map((item) => item.item_id));

  useEffect(() => {
    if (data && !loading) {
      const lastPage = Math.max(1, Math.ceil(data.total / PAGE_SIZE));
      if (page > lastPage) setPage(lastPage);
    }
  }, [data, loading, page]);

  async function addItem(item) {
    if (!selectedList) return;
    const target = selectedList;
    const key = target.id + ':' + item.id;
    setPending((previous) => new Set(previous).add(key));
    try {
      const response = await apiRequest('/lists/' + target.id + '/items', {
        method: 'POST', body: { item_id: item.id },
      });
      setRecentlySaved((previous) => new Set(previous).add(key));
      setMembershipsRevision((value) => value + 1);
      onDataChanged();
      notify(response.created
        ? item.symbol + ' added to ' + target.name + '.'
        : item.symbol + ' is already in ' + target.name + '.');
    } catch (requestError) {
      notify(displayError(requestError), 'error');
    } finally {
      setPending((previous) => {
        const next = new Set(previous);
        next.delete(key);
        return next;
      });
    }
  }

  return <section className="content-panel" aria-labelledby="catalogue-heading">
    <div className="panel-heading catalogue-heading">
      <div className="panel-title-group">
        <span className="collection-icon"><Icon name="globe" size={23} /></span>
        <div><h2 id="catalogue-heading">Find your next addition</h2><p>Explore fictional companies across the sample catalogue.</p></div>
      </div>
      <div className="target-selector">
        <label htmlFor="target-watchlist">Save to</label>
        <select id="target-watchlist" value={selectedListId || ''} disabled={!lists.length}
          onChange={(event) => onSelectTarget(Number(event.target.value))}>
          {!lists.length && <option value="">Create a watchlist first</option>}
          {lists.map((list) => <option key={list.id} value={list.id}>{list.name}</option>)}
        </select>
      </div>
    </div>

    {lists.length === 0 && <div className="inline-callout">
      <Icon name="folder" size={20} /><span>Create a watchlist to start saving symbols.</span>
      <button className="text-button" type="button" onClick={onCreate}>Create a watchlist<Icon name="plus" size={15} /></button>
    </div>}

    <div className="table-toolbar catalogue-toolbar">
      <SearchInput value={query} onChange={(value) => { setQuery(value); setPage(1); }}
        placeholder="Search by symbol or company…" label="Search catalogue" />
      <div className="sector-filter">
        <label htmlFor="sector-filter" className="sr-only">Filter catalogue by sector</label>
        <select id="sector-filter" value={sector} onChange={(event) => { setSector(event.target.value); setPage(1); }}>
          <option value="">All sectors</option>
          {sectors.map((name) => <option key={name} value={name}>{name}</option>)}
        </select>
      </div>
    </div>
    {memberships.error && <div className="inline-warning" role="status">
      Saved-item status is unavailable. Adding a symbol will still check its current status.
    </div>}

    {error ? <ErrorState message={error} onRetry={() => setRevision((value) => value + 1)} />
      : !data && loading ? <TableSkeleton />
      : data?.items.length === 0 ? <EmptyState icon="search" title="No matches this time"
          description="Try another search or choose a different sector."
          action={<button type="button" className="button button-secondary"
            onClick={() => { setQuery(''); setSector(''); setPage(1); }}>Clear filters</button>} />
      : <div className={'table-wrap' + (loading ? ' refreshing' : '')} aria-busy={loading}>
        <table className="items-table catalogue-table">
          <thead><tr><th scope="col">Company</th><th scope="col">Sector</th>
            <th scope="col" className="number-column">Reference price</th><th scope="col" className="number-column">Change</th>
            <th scope="col" className="catalogue-action-column"><span className="sr-only">Add to watchlist</span></th></tr></thead>
          <tbody>{data?.items.map((item) => {
            const key = selectedListId + ':' + item.id;
            const isPending = pending.has(key);
            const saved = savedItemIds.has(item.id) || recentlySaved.has(key);
            return <tr key={item.id}>
              <td><SymbolCell item={item} /></td><td><span className="sector-label">{item.sector}</span></td>
              <td className="number-column"><Price value={item.price} /></td>
              <td className="number-column"><Change value={item.change_percent} /></td>
              <td className="catalogue-action-column"><button type="button"
                className={'add-item-button' + (saved ? ' saved' : '')}
                disabled={!selectedList || isPending || saved || loading || memberships.loading}
                onClick={() => addItem(item)}
                aria-label={saved ? item.symbol + ' is saved' : 'Add ' + item.symbol + (selectedList ? ' to ' + selectedList.name : '')}>
                {isPending ? <><span className="spinner" />Saving</>
                  : saved ? <><Icon name="check" size={15} />Saved</>
                  : <><Icon name="plus" size={15} />Add</>}
              </button></td>
            </tr>;
          })}</tbody>
        </table>
      </div>}
    {!error && data && data.total > 0 && <Pagination page={page} total={data.total} onChange={setPage} loading={loading} />}
  </section>;
}
