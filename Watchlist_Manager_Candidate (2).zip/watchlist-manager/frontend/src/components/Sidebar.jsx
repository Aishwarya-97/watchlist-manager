import React from 'react';
import Icon from './Icon.jsx';

export default function Sidebar({ lists, selectedListId, view, onSelectList, onChangeView, onCreate, profile }) {
  return <aside className="sidebar">
    <div className="brand">
      <span className="brand-mark" aria-hidden="true"><i /><i /><i /></span>
      <span>folio<span className="brand-dot">.</span></span>
    </div>
    <p className="sidebar-kicker">PERSONAL WORKSPACE</p>
    <nav className="primary-nav" aria-label="Workspace">
      <button type="button" className={'nav-button' + (view === 'watchlists' ? ' active' : '')}
        onClick={() => onChangeView('watchlists')} aria-current={view === 'watchlists' ? 'page' : undefined}>
        <Icon name="grid" /><span>My watchlists</span>
      </button>
      <button type="button" className={'nav-button' + (view === 'catalogue' ? ' active' : '')}
        onClick={() => onChangeView('catalogue')} aria-current={view === 'catalogue' ? 'page' : undefined}>
        <Icon name="search" /><span>Explore catalogue</span>
      </button>
    </nav>
    <div className="sidebar-lists">
      <div className="sidebar-section-title"><span>YOUR LISTS</span>
        <button type="button" className="sidebar-add" aria-label="Create a watchlist" onClick={onCreate}>
          <Icon name="plus" size={16} />
        </button>
      </div>
      <nav className="list-nav" aria-label="Your watchlists">
        {lists.map((list, index) => <button type="button" key={list.id}
          className={'list-nav-button' + (view === 'watchlists' && selectedListId === list.id ? ' selected' : '')}
          onClick={() => onSelectList(list.id)} title={list.name}>
          <span className={'list-dot dot-' + index % 4} aria-hidden="true" />
          <span className="list-nav-name">{list.name}</span>
          <span className="list-nav-count">{list.item_count}</span>
        </button>)}
        {lists.length === 0 && <p className="sidebar-empty">Your collections will appear here.</p>}
      </nav>
    </div>
    <div className="sidebar-bottom">
      <div className="demo-note"><span className="status-dot" /><div><strong>A space to explore</strong><span>Sample data. Your own perspective.</span></div></div>
      <div className="profile">
        <div className="profile-avatar">{profile?.initials || 'AM'}</div>
        <div><strong>{profile?.name || 'Alex Morgan'}</strong><span>Personal workspace</span></div>
      </div>
    </div>
  </aside>;
}
