import React from 'react';
import Icon from './Icon.jsx';

export const PAGE_SIZE = 8;
export const EMPTY_ARRAY = [];

export function SearchInput({ value, onChange, placeholder, label }) {
  return <div className="search-field">
    <Icon name="search" size={18} />
    <input type="text" value={value} onChange={(event) => onChange(event.target.value)}
      placeholder={placeholder} aria-label={label} maxLength={100} />
    {value && <button type="button" className="clear-search" onClick={() => onChange('')}
      aria-label={'Clear ' + label.toLowerCase()}><Icon name="close" size={15} /></button>}
  </div>;
}

export function Pagination({ page, total, onChange, loading = false }) {
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const from = total === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;
  const to = Math.min(page * PAGE_SIZE, total);
  return <div className="pagination">
    <span>Showing <strong>{from}–{to}</strong> of <strong>{total}</strong></span>
    <div className="pagination-controls">
      <button type="button" className="page-button" disabled={page <= 1 || loading}
        onClick={() => onChange(page - 1)} aria-label="Previous page"><Icon name="left" size={16} /></button>
      <span>Page <strong>{page}</strong> of {pages}</span>
      <button type="button" className="page-button" disabled={page >= pages || loading}
        onClick={() => onChange(page + 1)} aria-label="Next page"><Icon name="right" size={16} /></button>
    </div>
  </div>;
}

export function SymbolCell({ item }) {
  const tone = [...item.symbol].reduce((sum, char) => sum + char.charCodeAt(0), 0) % 5;
  return <div className="symbol-cell">
    <span className={'symbol-avatar tone-' + tone}>{item.symbol.slice(0, 2)}</span>
    <div><span className="symbol-name">{item.symbol}</span><span className="company-name">{item.name}</span></div>
  </div>;
}

export function Price({ value }) {
  return <span className="price">{new Intl.NumberFormat('en-US', {
    style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2,
  }).format(value)}</span>;
}

export function Change({ value }) {
  const direction = value > 0 ? 'positive' : value < 0 ? 'negative' : 'neutral';
  return <span className={'change ' + direction}>
    {value !== 0 && <Icon name={value > 0 ? 'up' : 'down'} size={13} />}
    {value > 0 ? '+' : ''}{Number(value).toFixed(2)}%
  </span>;
}

export function EmptyState({ icon = 'bookmark', title, description, action }) {
  return <div className="empty-state">
    <div className="empty-icon"><Icon name={icon} size={28} /></div>
    <h3>{title}</h3><p>{description}</p>{action}
  </div>;
}

export function ErrorState({ message, onRetry }) {
  return <div className="error-state" role="alert">
    <Icon name="alert" size={24} /><div><h3>We couldn’t load this view</h3><p>{message}</p></div>
    <button type="button" className="button button-secondary button-small" onClick={onRetry}>Try again</button>
  </div>;
}

export function TableSkeleton() {
  return <div className="table-skeleton" role="status" aria-label="Loading items">
    {[1, 2, 3, 4].map((row) => <div className="skeleton-row" key={row}>
      <span className="skeleton skeleton-avatar" /><span className="skeleton skeleton-text" />
      <span className="skeleton skeleton-short" /><span className="skeleton skeleton-short" />
    </div>)}
  </div>;
}
