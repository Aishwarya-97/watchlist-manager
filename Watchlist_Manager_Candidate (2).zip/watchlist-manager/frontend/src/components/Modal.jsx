import React, { useEffect, useId, useRef } from 'react';
import Icon from './Icon.jsx';

export default function Modal({ title, description, children, onClose, busy = false, destructive = false }) {
  const titleId = useId();
  const descriptionId = useId();
  const dialogRef = useRef(null);
  const closeRef = useRef(onClose);
  const busyRef = useRef(busy);
  closeRef.current = onClose;
  busyRef.current = busy;

  useEffect(() => {
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const dialog = dialogRef.current;
    const initial = dialog.querySelector('[data-autofocus]') || dialog;
    initial.focus();

    function handleKey(event) {
      if (event.key === 'Escape' && !busyRef.current) closeRef.current();
      if (event.key !== 'Tab') return;
      const focusable = [...dialog.querySelectorAll(
        'button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex="0"]',
      )].filter((element) => element.getClientRects().length > 0);
      if (!focusable.length) {
        event.preventDefault();
        dialog.focus();
        return;
      }
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener('keydown', handleKey);
    return () => {
      document.removeEventListener('keydown', handleKey);
      document.body.style.overflow = previousOverflow;
      if (previousFocus instanceof HTMLElement && previousFocus.isConnected) previousFocus.focus();
    };
  }, []);

  return <div className="modal-backdrop" onMouseDown={(event) => {
    if (event.target === event.currentTarget && !busy) onClose();
  }}>
    <section className="modal" ref={dialogRef} tabIndex={-1} role="dialog" aria-modal="true"
      aria-labelledby={titleId} aria-describedby={description ? descriptionId : undefined}>
      <div className={'modal-illustration' + (destructive ? ' destructive' : '')}>
        <Icon name={destructive ? 'trash' : 'folder'} size={24} />
      </div>
      <button type="button" className="icon-button modal-close" aria-label="Close dialog"
        onClick={onClose} disabled={busy}><Icon name="close" size={20} /></button>
      <h2 id={titleId}>{title}</h2>
      {description && <p className="modal-description" id={descriptionId}>{description}</p>}
      {children}
    </section>
  </div>;
}
