"""API behavior checks for the local demo."""
