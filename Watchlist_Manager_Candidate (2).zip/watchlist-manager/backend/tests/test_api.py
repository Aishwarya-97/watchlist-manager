"""Run from the project root: python -m unittest discover -s backend/tests -v."""

from pathlib import Path
from contextlib import closing
import sqlite3
import sys
import tempfile
import unittest

from fastapi.testclient import TestClient

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from app.main import create_app


class ApiTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp.name) / "test.db"
        self.client = TestClient(create_app(self.db_path, write_delay_ms=0))
        self.client.__enter__()

    def tearDown(self):
        self.client.__exit__(None, None, None)
        self.temp.cleanup()

    def test_health_and_profile(self):
        self.assertEqual(self.client.get("/api/health").json(), {"status": "ok"})
        self.assertEqual(self.client.get("/api/profile").json()["id"], 1)

    def test_catalog_is_paginated_and_sorted(self):
        first = self.client.get("/api/catalog").json()
        second = self.client.get("/api/catalog?page=2").json()
        self.assertEqual(first["total"], 24)
        self.assertEqual(len(first["items"]), 8)
        self.assertEqual(first["page_size"], 8)
        self.assertEqual(len(first["sectors"]), 6)
        self.assertFalse({item["id"] for item in first["items"]} &
                         {item["id"] for item in second["items"]})
        symbols = [item["symbol"] for item in first["items"] + second["items"]]
        self.assertEqual(symbols, sorted(symbols))

    def test_catalog_search_and_sector_filter_share_a_total(self):
        results = self.client.get("/api/catalog", params={"q": "ARCL", "sector": "Technology"}).json()
        self.assertEqual(results["total"], 1)
        self.assertEqual(results["items"][0]["name"], "Arclight Systems")
        results = self.client.get("/api/catalog", params={"q": "ARCL", "sector": "Energy"}).json()
        self.assertEqual(results["total"], 0)

    def test_search_treats_wildcards_as_literal_characters(self):
        for query in ("%", "_", "' OR 1=1 --"):
            with self.subTest(query=query):
                result = self.client.get("/api/catalog", params={"q": query})
                self.assertEqual(result.status_code, 200)
                self.assertEqual(result.json()["total"], 0)

    def test_seeded_lists_include_empty_lists_and_correct_counts(self):
        result = self.client.get("/api/lists").json()
        self.assertEqual(result["total"], 3)
        self.assertEqual([item["item_count"] for item in result["items"]], [9, 5, 0])
        empty = self.client.get("/api/lists/3/items").json()
        self.assertEqual(empty["total"], 0)
        self.assertEqual(empty["items"], [])

    def test_create_update_and_delete_a_list(self):
        created = self.client.post("/api/lists", json={"name": "  New ideas  ", "description": "A shortlist."})
        self.assertEqual(created.status_code, 201)
        data = created.json()
        self.assertEqual(data["name"], "New ideas")
        self.assertEqual(data["item_count"], 0)
        list_id = data["id"]
        updated = self.client.patch(f"/api/lists/{list_id}", json={"name": "Review next"})
        self.assertEqual(updated.status_code, 200)
        self.assertEqual(updated.json()["name"], "Review next")
        self.assertEqual(updated.json()["description"], "A shortlist.")
        deleted = self.client.delete(f"/api/lists/{list_id}")
        self.assertEqual(deleted.status_code, 204)
        self.assertEqual(deleted.content, b"")
        self.assertEqual(self.client.get(f"/api/lists/{list_id}/items").status_code, 404)

    def test_add_repeat_and_remove_an_item(self):
        first = self.client.post("/api/lists/3/items", json={"item_id": 5})
        self.assertEqual(first.status_code, 201)
        self.assertTrue(first.json()["created"])
        entry_id = first.json()["item"]["entry_id"]
        repeat = self.client.post("/api/lists/3/items", json={"item_id": 5})
        self.assertEqual(repeat.status_code, 200)
        self.assertFalse(repeat.json()["created"])
        self.assertEqual(repeat.json()["item"]["entry_id"], entry_id)
        self.assertEqual(self.client.get("/api/lists/3/items").json()["total"], 1)
        self.assertEqual(self.client.get("/api/lists").json()["items"][2]["item_count"], 1)
        removed = self.client.delete(f"/api/lists/3/items/{entry_id}")
        self.assertEqual(removed.status_code, 204)
        self.assertEqual(self.client.get("/api/lists/3/items").json()["total"], 0)
        self.assertEqual(self.client.delete(f"/api/lists/3/items/{entry_id}").status_code, 404)

    def test_same_catalogue_item_can_be_in_two_different_lists(self):
        first = self.client.post("/api/lists/3/items", json={"item_id": 1})
        self.assertEqual(first.status_code, 201)
        self.assertEqual(self.client.get("/api/lists/1/items", params={"q": "ARCL"}).json()["total"], 1)
        self.assertEqual(self.client.get("/api/lists/3/items", params={"q": "ARCL"}).json()["total"], 1)

    def test_list_search_returns_the_filtered_count(self):
        result = self.client.get("/api/lists/1/items", params={"q": "ATLS", "page_size": 1}).json()
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["items"][0]["symbol"], "ATLS")
        self.assertEqual(self.client.get("/api/lists/1/items?page=2&page_size=1&q=ATLS").json()["items"], [])

    def test_deleting_a_list_cascades_its_memberships(self):
        self.assertEqual(self.client.delete("/api/lists/1").status_code, 204)
        with closing(sqlite3.connect(self.db_path)) as connection:
            count = connection.execute("SELECT COUNT(*) FROM watchlist_items WHERE list_id = 1").fetchone()[0]
        self.assertEqual(count, 0)
        self.assertEqual(self.client.get("/api/catalog").json()["total"], 24)

    def test_other_users_lists_are_not_exposed(self):
        operations = [
            self.client.get("/api/lists/4/items"),
            self.client.patch("/api/lists/4", json={"name": "Changed"}),
            self.client.delete("/api/lists/4"),
            self.client.post("/api/lists/4/items", json={"item_id": 1}),
            self.client.delete("/api/lists/4/items/15"),
        ]
        self.assertTrue(all(result.status_code == 404 for result in operations))

    def test_cannot_remove_an_entry_through_a_different_list(self):
        entry_id = self.client.get("/api/lists/1/items").json()["items"][0]["entry_id"]
        self.assertEqual(self.client.delete(f"/api/lists/2/items/{entry_id}").status_code, 404)
        self.assertEqual(self.client.get("/api/lists/1/items").json()["total"], 9)

    def test_unknown_resources_return_readable_errors(self):
        missing_list = self.client.get("/api/lists/999/items")
        self.assertEqual(missing_list.status_code, 404)
        self.assertIsInstance(missing_list.json()["detail"], str)
        missing_item = self.client.post("/api/lists/3/items", json={"item_id": 999})
        self.assertEqual(missing_item.status_code, 404)
        self.assertEqual(self.client.get("/api/not-an-endpoint").status_code, 404)

    def test_invalid_list_inputs(self):
        for payload in ({"name": "   "}, {"name": "x" * 61},
                        {"name": "Fine", "description": "x" * 161},
                        {"name": "Fine", "owner_id": 2}):
            with self.subTest(payload=payload):
                result = self.client.post("/api/lists", json=payload)
                self.assertEqual(result.status_code, 422)
                self.assertIsInstance(result.json()["detail"], str)
        for payload in ({}, {"name": None}, {"description": None}):
            with self.subTest(payload=payload):
                self.assertEqual(self.client.patch("/api/lists/1", json=payload).status_code, 422)

    def test_invalid_pagination_and_item_inputs(self):
        for path in ("/api/catalog?page=0", "/api/catalog?page_size=101",
                     "/api/catalog?page=not-a-number", "/api/lists/1/items?page_size=0",
                     "/api/lists/0/items", "/api/catalog?q=" + "a" * 101):
            with self.subTest(path=path):
                self.assertEqual(self.client.get(path).status_code, 422)
        for value in (0, -1, "1", True, None):
            with self.subTest(value=value):
                self.assertEqual(self.client.post("/api/lists/3/items", json={"item_id": value}).status_code, 422)

    def test_restart_preserves_changes_instead_of_reseeding(self):
        self.client.delete("/api/lists/3")
        second = TestClient(create_app(self.db_path, write_delay_ms=0))
        with second:
            self.assertEqual(second.get("/api/lists").json()["total"], 2)


if __name__ == "__main__":
    unittest.main()
