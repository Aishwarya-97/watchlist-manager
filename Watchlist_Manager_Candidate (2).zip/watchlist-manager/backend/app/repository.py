"""Data access for the catalogue and the current demo user's watchlists."""

from pathlib import Path
import sqlite3
import time

from .database import connect


class NotFoundError(Exception):
    """A requested resource is absent or outside the current user's workspace."""


ENTRY_COLUMNS = """
    wi.id AS entry_id, wi.item_id, c.symbol, c.name, c.sector,
    c.exchange, c.price, c.change_percent, wi.added_at
"""


def search_pattern(query: str) -> str:
    """Treat percent and underscore as search characters, not SQL wildcards."""
    escaped = query.strip().replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{escaped}%"


class WatchlistRepository:
    def __init__(self, db_path: str | Path, user_id: int = 1, write_delay_ms: int = 200):
        self.db_path = Path(db_path)
        self.user_id = user_id
        self.write_delay_ms = write_delay_ms

    def catalog(self, query: str, sector: str, page: int, page_size: int) -> dict:
        clauses: list[str] = []
        params: list = []
        if query.strip():
            clauses.append("(symbol LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\')")
            params.extend([search_pattern(query)] * 2)
        if sector.strip():
            clauses.append("sector = ?")
            params.append(sector.strip())
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        with connect(self.db_path) as connection:
            total = connection.execute(
                f"SELECT COUNT(*) FROM catalog_items {where}", params
            ).fetchone()[0]
            rows = connection.execute(
                f"""SELECT id, symbol, name, sector, exchange, price, change_percent
                    FROM catalog_items {where}
                    ORDER BY symbol, id LIMIT ? OFFSET ?""",
                [*params, page_size, (page - 1) * page_size],
            ).fetchall()
            sectors = [row[0] for row in connection.execute(
                "SELECT DISTINCT sector FROM catalog_items ORDER BY sector"
            )]
        return {"items": [dict(row) for row in rows], "total": total,
                "page": page, "page_size": page_size, "sectors": sectors}

    def lists(self) -> dict:
        with connect(self.db_path) as connection:
            rows = connection.execute(
                """SELECT w.id, w.name, w.description, w.created_at,
                          COUNT(wi.id) AS item_count
                   FROM watchlists w LEFT JOIN watchlist_items wi ON wi.list_id = w.id
                   WHERE w.owner_id = ? GROUP BY w.id ORDER BY w.id""",
                (self.user_id,),
            ).fetchall()
        return {"items": [dict(row) for row in rows], "total": len(rows)}

    def _require_list(self, connection: sqlite3.Connection, list_id: int) -> sqlite3.Row:
        row = connection.execute(
            "SELECT * FROM watchlists WHERE id = ? AND owner_id = ?",
            (list_id, self.user_id),
        ).fetchone()
        if row is None:
            raise NotFoundError("Watchlist not found")
        return row

    def _list(self, connection: sqlite3.Connection, list_id: int) -> dict:
        self._require_list(connection, list_id)
        row = connection.execute(
            """SELECT w.id, w.name, w.description, w.created_at,
                      COUNT(wi.id) AS item_count
               FROM watchlists w LEFT JOIN watchlist_items wi ON wi.list_id = w.id
               WHERE w.id = ? GROUP BY w.id""",
            (list_id,),
        ).fetchone()
        return dict(row)

    def create_list(self, name: str, description: str = "") -> dict:
        with connect(self.db_path) as connection:
            with connection:
                cursor = connection.execute(
                    "INSERT INTO watchlists (owner_id, name, description) VALUES (?, ?, ?)",
                    (self.user_id, name, description),
                )
            return self._list(connection, cursor.lastrowid)

    def update_list(self, list_id: int, name: str | None = None,
                    description: str | None = None) -> dict:
        with connect(self.db_path) as connection:
            current = self._require_list(connection, list_id)
            with connection:
                connection.execute(
                    "UPDATE watchlists SET name = ?, description = ? WHERE id = ?",
                    (name if name is not None else current["name"],
                     description if description is not None else current["description"],
                     list_id),
                )
            return self._list(connection, list_id)

    def delete_list(self, list_id: int) -> None:
        with connect(self.db_path) as connection:
            self._require_list(connection, list_id)
            with connection:
                connection.execute("DELETE FROM watchlists WHERE id = ?", (list_id,))

    def list_items(self, list_id: int, query: str, page: int, page_size: int) -> dict:
        where = "WHERE wi.list_id = ?"
        params: list = [list_id]
        if query.strip():
            where += " AND (c.symbol LIKE ? ESCAPE '\\' OR c.name LIKE ? ESCAPE '\\')"
            params.extend([search_pattern(query)] * 2)
        source = "FROM watchlist_items wi JOIN catalog_items c ON c.id = wi.item_id"
        with connect(self.db_path) as connection:
            self._require_list(connection, list_id)
            total = connection.execute(
                f"SELECT COUNT(*) {source} {where}", params
            ).fetchone()[0]
            rows = connection.execute(
                f"""SELECT {ENTRY_COLUMNS} {source} {where}
                    ORDER BY wi.added_at DESC, wi.id DESC LIMIT ? OFFSET ?""",
                [*params, page_size, (page - 1) * page_size],
            ).fetchall()
        return {"items": [dict(row) for row in rows], "total": total,
                "page": page, "page_size": page_size}

    def _entry(self, connection: sqlite3.Connection, entry_id: int) -> dict:
        row = connection.execute(
            f"""SELECT {ENTRY_COLUMNS} FROM watchlist_items wi
                JOIN catalog_items c ON c.id = wi.item_id WHERE wi.id = ?""",
            (entry_id,),
        ).fetchone()
        return dict(row)

    def find_existing(self, connection: sqlite3.Connection,
                      list_id: int, item_id: int) -> dict | None:
        row = connection.execute(
            """SELECT id FROM watchlist_items
               WHERE list_id = ? AND item_id = ? ORDER BY id LIMIT 1""",
            (list_id, item_id),
        ).fetchone()
        return self._entry(connection, row["id"]) if row else None

    def add_item(self, list_id: int, item_id: int) -> tuple[dict, bool]:
        with connect(self.db_path) as connection:
            self._require_list(connection, list_id)
            if connection.execute(
                "SELECT id FROM catalog_items WHERE id = ?", (item_id,)
            ).fetchone() is None:
                raise NotFoundError("Catalogue item not found")

            existing = self.find_existing(connection, list_id, item_id)
            if existing:
                return existing, False

            # Model downstream persistence latency in the local demo environment.
            if self.write_delay_ms:
                time.sleep(self.write_delay_ms / 1000)

            try:
                with connection:
                    cursor = connection.execute(
                        "INSERT INTO watchlist_items (list_id, item_id) VALUES (?, ?)",
                        (list_id, item_id),
                    )
            except sqlite3.IntegrityError:
                raise NotFoundError("Watchlist or catalogue item no longer exists") from None
            return self._entry(connection, cursor.lastrowid), True

    def remove_item(self, list_id: int, entry_id: int) -> None:
        with connect(self.db_path) as connection:
            self._require_list(connection, list_id)
            with connection:
                cursor = connection.execute(
                    "DELETE FROM watchlist_items WHERE id = ? AND list_id = ?",
                    (entry_id, list_id),
                )
                if cursor.rowcount == 0:
                    raise NotFoundError("Saved item not found")
