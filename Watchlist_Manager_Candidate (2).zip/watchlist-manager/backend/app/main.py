"""HTTP API and optional serving of the prebuilt React application."""

from contextlib import asynccontextmanager
import os
from pathlib import Path as FilePath
from typing import Annotated

from fastapi import FastAPI, Path, Query, Request, Response, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from .database import DEFAULT_DB_PATH, initialize_database
from .models import ItemCreate, WatchlistCreate, WatchlistUpdate
from .repository import NotFoundError, WatchlistRepository


ResourceId = Annotated[int, Path(ge=1)]
PageNumber = Annotated[int, Query(ge=1, le=10_000)]
PageSize = Annotated[int, Query(ge=1, le=100)]
SearchQuery = Annotated[str, Query(max_length=100)]


def create_app(db_path: str | FilePath | None = None,
               write_delay_ms: int | None = None) -> FastAPI:
    resolved_path = FilePath(db_path or os.environ.get("WATCHLIST_DB") or DEFAULT_DB_PATH)
    delay = write_delay_ms if write_delay_ms is not None else int(
        os.environ.get("WATCHLIST_WRITE_DELAY_MS", "200")
    )
    if not 0 <= delay <= 10_000:
        raise ValueError("WATCHLIST_WRITE_DELAY_MS must be between 0 and 10000")
    repository = WatchlistRepository(resolved_path, write_delay_ms=delay)

    @asynccontextmanager
    async def lifespan(_app: FastAPI):
        initialize_database(resolved_path)
        yield

    application = FastAPI(
        title="Watchlist Manager API",
        description="A local demo with a fictional catalogue and a fixed sample user.",
        version="1.0.0",
        lifespan=lifespan,
    )
    application.state.repository = repository
    application.state.db_path = resolved_path

    @application.exception_handler(NotFoundError)
    async def not_found(_request: Request, exception: NotFoundError):
        return JSONResponse(status_code=404, content={"detail": str(exception)})

    @application.exception_handler(RequestValidationError)
    async def invalid_request(_request: Request, exception: RequestValidationError):
        messages = []
        for error in exception.errors():
            field = ".".join(str(part) for part in error["loc"] if part not in ("body", "query", "path"))
            messages.append(f"{field}: {error['msg']}" if field else error["msg"])
        return JSONResponse(status_code=422, content={"detail": "; ".join(messages)})

    @application.get("/api/health", tags=["System"])
    def health():
        return {"status": "ok"}

    @application.get("/api/profile", tags=["System"])
    def profile():
        return {"id": 1, "name": "Alex Morgan", "email": "alex@example.test", "initials": "AM"}

    @application.get("/api/catalog", tags=["Catalogue"])
    def catalog(q: SearchQuery = "", sector: Annotated[str, Query(max_length=64)] = "",
                page: PageNumber = 1, page_size: PageSize = 8):
        return repository.catalog(q, sector, page, page_size)

    @application.get("/api/lists", tags=["Watchlists"])
    def lists():
        return repository.lists()

    @application.post("/api/lists", status_code=status.HTTP_201_CREATED, tags=["Watchlists"])
    def create_list(payload: WatchlistCreate):
        return repository.create_list(payload.name, payload.description)

    @application.patch("/api/lists/{list_id}", tags=["Watchlists"])
    def update_list(list_id: ResourceId, payload: WatchlistUpdate):
        return repository.update_list(list_id, **payload.model_dump(exclude_unset=True))

    @application.delete("/api/lists/{list_id}", status_code=204, tags=["Watchlists"])
    def delete_list(list_id: ResourceId):
        repository.delete_list(list_id)
        return Response(status_code=204)

    @application.get("/api/lists/{list_id}/items", tags=["Saved items"])
    def items(list_id: ResourceId, q: SearchQuery = "",
              page: PageNumber = 1, page_size: PageSize = 8):
        return repository.list_items(list_id, q, page, page_size)

    @application.post("/api/lists/{list_id}/items", status_code=201, tags=["Saved items"])
    def add_item(list_id: ResourceId, payload: ItemCreate, response: Response):
        item, created = repository.add_item(list_id, payload.item_id)
        response.status_code = 201 if created else 200
        return {"item": item, "created": created}

    @application.delete("/api/lists/{list_id}/items/{entry_id}", status_code=204, tags=["Saved items"])
    def remove_item(list_id: ResourceId, entry_id: ResourceId):
        repository.remove_item(list_id, entry_id)
        return Response(status_code=204)

    static_dir = FilePath(__file__).resolve().parents[1] / "static"
    if static_dir.is_dir() and (static_dir / "index.html").is_file():
        application.mount("/", StaticFiles(directory=static_dir, html=True), name="frontend")
    else:
        @application.get("/", include_in_schema=False)
        def frontend_unavailable():
            return {
                "message": "The API is running. Build the frontend or start its development server.",
                "api_docs": "/docs",
            }
    return application


app = create_app()
