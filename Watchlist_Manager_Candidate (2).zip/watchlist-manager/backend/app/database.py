"""SQLite schema, demo data, and short-lived database connections."""

from contextlib import contextmanager
from pathlib import Path
import sqlite3


DEFAULT_DB_PATH = Path(__file__).resolve().parents[1] / "data" / "watchlist.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS catalog_items (
    id INTEGER PRIMARY KEY,
    symbol TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    sector TEXT NOT NULL,
    exchange TEXT NOT NULL,
    price REAL NOT NULL CHECK (price >= 0),
    change_percent REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS watchlists (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER NOT NULL REFERENCES users(id),
    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 60),
    description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 160),
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS watchlist_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    list_id INTEGER NOT NULL REFERENCES watchlists(id) ON DELETE CASCADE,
    item_id INTEGER NOT NULL REFERENCES catalog_items(id),
    added_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE INDEX IF NOT EXISTS idx_watchlists_owner ON watchlists(owner_id);
CREATE INDEX IF NOT EXISTS idx_watchlist_items_list ON watchlist_items(list_id);

CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""


# This catalogue is fictional. Prices and daily moves are static sample values.
CATALOG = [
    (1, "ARCL", "Arclight Systems", "Technology", "DEMO", 184.32, 1.84),
    (2, "NOVA", "Novara Cloud", "Technology", "DEMO", 92.18, -0.62),
    (3, "PYNE", "Pinecrest Software", "Technology", "DEMO", 247.60, 2.14),
    (4, "ORBT", "Orbit Semiconductor", "Technology", "DEMO", 136.45, 0.91),
    (5, "VERA", "Veridian Health", "Healthcare", "DEMO", 78.94, 0.48),
    (6, "LMNA", "Lumina Therapeutics", "Healthcare", "DEMO", 113.72, 1.32),
    (7, "CEDR", "Cedar Diagnostics", "Healthcare", "DEMO", 56.81, -1.07),
    (8, "WELL", "Wellhaven Medical", "Healthcare", "DEMO", 162.30, 0.26),
    (9, "FLDR", "Fieldstone Robotics", "Industrials", "DEMO", 129.64, 1.08),
    (10, "BRDG", "Bridgeway Logistics", "Industrials", "DEMO", 48.52, -0.35),
    (11, "ALTO", "Alto Precision", "Industrials", "DEMO", 211.08, 0.73),
    (12, "RIVT", "Rivet Manufacturing", "Industrials", "DEMO", 67.45, -0.92),
    (13, "MESA", "Mesa Consumer Goods", "Consumer", "DEMO", 88.10, 0.67),
    (14, "HBRN", "Harbor & North", "Consumer", "DEMO", 143.28, 1.55),
    (15, "FENN", "Fennel Foods", "Consumer", "DEMO", 39.76, -0.18),
    (16, "LUMA", "Luma Retail", "Consumer", "DEMO", 105.93, -1.24),
    (17, "SOLR", "Solara Renewables", "Energy", "DEMO", 74.62, 2.61),
    (18, "TIDE", "Tidewater Energy", "Energy", "DEMO", 118.40, -0.44),
    (19, "GRDN", "Gridline Storage", "Energy", "DEMO", 61.25, 1.76),
    (20, "AERO", "Aero Wind Partners", "Energy", "DEMO", 97.14, -0.81),
    (21, "ATLS", "Atlas Financial", "Financials", "DEMO", 156.87, 0.95),
    (22, "MRDN", "Meridian Payments", "Financials", "DEMO", 203.56, 1.18),
    (23, "OAKS", "Oakstone Capital", "Financials", "DEMO", 82.43, -0.57),
    (24, "SUMT", "Summit Assurance", "Financials", "DEMO", 124.90, 0.39),
]


@contextmanager
def connect(db_path: str | Path):
    """Open one connection for the current request or operation."""
    connection = sqlite3.connect(str(db_path), timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    try:
        yield connection
    finally:
        connection.close()


def initialize_database(db_path: str | Path) -> None:
    """Create a fresh database and seed it once, preserving later user changes."""
    path = Path(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with connect(path) as connection:
        connection.execute("PRAGMA journal_mode = WAL")
        connection.executescript(SCHEMA)
        seeded = connection.execute(
            "SELECT value FROM app_meta WHERE key = 'seed_version'"
        ).fetchone()
        if seeded:
            return

        with connection:
            connection.executemany(
                "INSERT INTO users (id, name, email) VALUES (?, ?, ?)",
                [
                    (1, "Alex Morgan", "alex@example.test"),
                    (2, "Casey Lee", "casey@example.test"),
                ],
            )
            connection.executemany(
                """INSERT INTO catalog_items
                   (id, symbol, name, sector, exchange, price, change_percent)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                CATALOG,
            )
            connection.executemany(
                """INSERT INTO watchlists
                   (id, owner_id, name, description, created_at)
                   VALUES (?, ?, ?, ?, ?)""",
                [
                    (1, 1, "Focus List", "A considered shortlist for closer research.", "2026-11-01T09:00:00.000Z"),
                    (2, 1, "Growth Radar", "Emerging ideas and businesses to follow.", "2026-11-02T09:00:00.000Z"),
                    (3, 1, "Research Queue", "A clean slate for the next promising idea.", "2026-11-03T09:00:00.000Z"),
                    (4, 2, "Casey's Private List", "Another demo user's list.", "2026-11-01T09:00:00.000Z"),
                ],
            )
            memberships = (
                [(1, item_id) for item_id in (1, 3, 6, 9, 13, 18, 21, 23, 24)]
                + [(2, item_id) for item_id in (2, 4, 7, 12, 14)]
                + [(4, 22)]
            )
            connection.executemany(
                """INSERT INTO watchlist_items (list_id, item_id, added_at)
                   VALUES (?, ?, ?)""",
                [
                    (list_id, item_id, f"2026-11-04T09:{index:02d}:00.000Z")
                    for index, (list_id, item_id) in enumerate(memberships)
                ],
            )
            connection.execute(
                "INSERT INTO app_meta (key, value) VALUES ('seed_version', '1')"
            )
