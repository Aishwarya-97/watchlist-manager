"""Request models keep the API's validation rules in one place."""

from pydantic import BaseModel, ConfigDict, Field, model_validator


class RequestModel(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class WatchlistCreate(RequestModel):
    name: str = Field(min_length=1, max_length=60)
    description: str = Field(default="", max_length=160)


class WatchlistUpdate(RequestModel):
    name: str | None = Field(default=None, min_length=1, max_length=60)
    description: str | None = Field(default=None, max_length=160)

    @model_validator(mode="after")
    def validate_changes(self):
        if not self.model_fields_set:
            raise ValueError("Provide a name or description to update")
        for field in self.model_fields_set:
            if getattr(self, field) is None:
                raise ValueError(f"{field} cannot be null")
        return self


class ItemCreate(RequestModel):
    item_id: int = Field(gt=0, strict=True)
