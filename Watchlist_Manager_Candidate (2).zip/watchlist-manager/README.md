# Folio — Personal Watchlist Manager

A compact full-stack interview application: React, a Python/FastAPI API, and SQLite. The project contains a running application and source code for you to inspect, debug, and extend. The interviewer will provide the task and acceptance criteria during the session.

All companies, prices, accounts, and other records are fictional sample data. The application uses a fixed demo identity, Alex Morgan; authentication is outside the exercise. There is no connection to live market data or an external database.

## Start on Windows

1. Extract the entire ZIP. Work from the extracted `watchlist-manager` folder, not from inside the ZIP viewer.
2. Install Python 3.11 or newer if necessary (Python 3.12 is recommended).
3. Open PowerShell or Command Prompt in the project folder and run (also documented in `START_HERE.txt`):

```powershell
py -3 manage.py start
```

4. Open **http://127.0.0.1:8000** after the terminal reports that startup is complete.

The first run creates `.venv/` and downloads the pinned Python dependencies. Internet access is required for that setup. Subsequent runs reuse the environment. The React frontend is already built and included, so **Node.js is not needed just to start or explore the packaged application**.

Keep the terminal open while using the application. Press `Ctrl+C` to stop. If `py` is unavailable but `python` works, use `python manage.py start`.

## Start on macOS or Linux

```bash
python3 manage.py start
```

Python must include `venv` and `pip`. On distributions that package them separately, install those operating-system packages first. The application creates its SQLite database and sample records automatically at startup.

## Work on the source

### Backend development

Run with source reloading:

```powershell
py -3 manage.py start --reload
```

On macOS/Linux, substitute `python3` for `py -3`.

### Frontend development

Install **Node.js 22.12+ or Node.js 24**. Keep the API running on port 8000. In a second terminal:

```bash
cd frontend
npm ci
npm run dev
```

Open the development address printed by Vite (normally **http://localhost:5173**). The development server forwards `/api` requests to the API on port 8000. Edit the files in `frontend/src/` and inspect the result in this development browser tab.

The browser tab on port 8000 serves the previously built frontend. To update that bundled version after source changes:

```bash
cd frontend
npm run build
```

Refresh the port-8000 page after the build. The build writes into `backend/static/`. Both the readable source and this built output are included in the project.

Run the frontend API-helper tests from `frontend/` with `npm test`.

## Tests, API documentation, and data

Run the supplied backend tests:

```powershell
py -3 manage.py test
```

The tests use temporary databases and do not change your working sample data. They cover a selection of existing behavior, not every requirement or edge case. Add your own tests as appropriate.

- API documentation: **http://127.0.0.1:8000/docs**
- Health check: **http://127.0.0.1:8000/api/health**
- Default database: `backend/data/watchlist.db`
- SQL schema and seed setup: `backend/app/database.py`

SQLite is included with Python. You can inspect the database with any SQLite client, or use Python's built-in `sqlite3` module. Keep database files out of your source submission unless the interviewer requests one.

To restore the original sample data, stop the application first, then run:

```powershell
py -3 manage.py reset --yes
```

This saves a timestamped backup and resets only the default local demo database. Starting the app again recreates the sample records. A custom database selected through `WATCHLIST_DB` is not affected by this command.

## Docker alternative

If Docker with Compose is already available:

```bash
docker compose up --build
```

Open **http://127.0.0.1:8000**. This builds the frontend and runs the API with a persistent SQLite volume. Native Python/Node installations are not needed for this route. The first build requires internet access to obtain images and packages.

- View logs: `docker compose logs -f`
- Run backend tests: `docker compose exec watchlist python -m unittest discover -s backend/tests -v`
- Stop: `docker compose down`
- Rebuild after changing source: `docker compose up --build`

This Docker route serves a built frontend; it does not hot-reload source changes. Data survives ordinary container recreation. To intentionally discard **only this Compose project's demo volume**, stop the app with `docker compose down -v`; the next startup creates fresh sample data. Native `manage.py reset` does not reset the Docker volume.

## Project map

| Location | Purpose |
| --- | --- |
| `frontend/src/` | React components, API requests, and styles |
| `frontend/package-lock.json` | Locked frontend dependency versions |
| `backend/app/main.py` | HTTP routes and application startup |
| `backend/app/models.py` | Request validation |
| `backend/app/repository.py` | Database operations |
| `backend/app/database.py` | Schema and sample data |
| `backend/tests/` | Supplied behavior tests |
| `backend/static/` | Bundled React build |
| `manage.py` | Python setup, run, test, and demo-reset commands |

### Manual backend commands

If you prefer to manage the virtual environment yourself:

```bash
python -m venv .venv
# Activate .venv using the command for your shell.
python -m pip install -r backend/requirements.txt
python -m uvicorn app.main:app --app-dir backend --host 127.0.0.1 --port 8000
```

Run tests from the backend directory, with that environment active:

```bash
cd backend
python -m unittest discover -s tests -v
```

## Configuration

| Variable | Default | Meaning |
| --- | --- | --- |
| `WATCHLIST_DB` | `backend/data/watchlist.db` | SQLite file to use |
| `WATCHLIST_WRITE_DELAY_MS` | `200` | Simulated persistence latency for the sample application |
| `VITE_API_TARGET` | `http://127.0.0.1:8000` | API target for Vite's development proxy |

## Troubleshooting

- **Port 8000 is occupied:** stop the other process, or use `python manage.py start --port 8001` and open the corresponding address. For frontend development, set `VITE_API_TARGET` to that API address before running Vite.
- **The browser still shows old frontend code:** use the Vite development address, or rebuild the frontend and refresh the port-8000 page.
- **Dependency download fails:** check network access to the Python/npm registries. Retry setup with `python manage.py setup` after resolving the connection issue.
- **Python is not found:** install Python and reopen the terminal; try `python --version` and `py -3 --version` to confirm the available launcher.
- **Docker is not available:** use the native Python route. Docker is optional.
- **You want to hand over your changes:** return the changed source files and tests, or a ZIP of the project excluding `.venv/`, `frontend/node_modules/`, generated database files, and caches. Explain what you verified and what remains incomplete.
